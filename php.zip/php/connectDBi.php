<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET,PUSH,PUT,DELETE");
$hostname = "fdb12.biz.ht";
$username = "2181404_club";
$password = "jimmy123456";  // update mysql password
$dbname = "2181404_club";
$conn = mysqli_connect($hostname, $username, $password, $dbname);
?>