<?php

include "connectDBi.php";



try {

	$userid = $_GET["username"];

	$userpw = $_GET["password"];

	$sql = "SELECT * FROM login where userid='$userid' and userpw='$userpw' LIMIT 1";

	$result = mysqli_query($conn, $sql);

	//echo json_encode("u:".$userid."p:".$userpw."sql:".$sql);

	if(mysqli_num_rows($result) == 1) {

		echo json_encode("true");

	} else {

		echo json_encode("false");

	}

	

} catch(Exception $e) {

	echo json_encode($e->getMessage());

}