<?php

include "connectDBi.php";



try {

	$userid = $_POST["username"];

	$userpw = $_POST["password"];

	$email = $_POST["email"];

	

	$sql = "SELECT * FROM login where userid = '$userid' LIMIT 1";

	$result = mysqli_query($conn, $sql);

	

	if(mysqli_num_rows($result) == 1) {

		echo json_encode("false");

	} else {

		$sql = "INSERT INTO login (userid,userpw,email) VALUES('$userid','$userpw','$email')";

		$result = mysqli_query($conn, $sql);

		

		if($result == 1) {

			echo json_encode("true");

		} else {

			echo json_encode("false");

		}		

	}	

} catch(Exception $e) {

	echo json_encode($e->getMessage());

}